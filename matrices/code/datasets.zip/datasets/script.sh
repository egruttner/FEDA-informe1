g++ -o main main.cpp
./main